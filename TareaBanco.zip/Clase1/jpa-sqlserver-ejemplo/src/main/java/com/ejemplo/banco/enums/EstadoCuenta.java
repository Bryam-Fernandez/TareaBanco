package com.ejemplo.banco.enums;

public enum EstadoCuenta {

	   ACTIVA, INACTIVA, CERRADA, BLOQUEADA

	}