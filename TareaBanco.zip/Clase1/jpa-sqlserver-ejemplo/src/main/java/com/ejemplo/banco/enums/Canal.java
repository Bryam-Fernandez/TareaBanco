package com.ejemplo.banco.enums;

public enum Canal {

	   CAJERO, VENTANILLA, ONLINE, MOBILE

	}