package com.ejemplo.banco.enums;

public enum TipoCuenta {

	   AHORRO, CORRIENTE, PLAZO_FIJO

	}