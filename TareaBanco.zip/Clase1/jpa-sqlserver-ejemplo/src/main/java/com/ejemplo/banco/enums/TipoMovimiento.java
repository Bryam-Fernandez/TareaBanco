package com.ejemplo.banco.enums;


public enum TipoMovimiento {

   DEPOSITO, RETIRO, TRANSFERENCIA_ENVIADA, TRANSFERENCIA_RECIBIDA

}
