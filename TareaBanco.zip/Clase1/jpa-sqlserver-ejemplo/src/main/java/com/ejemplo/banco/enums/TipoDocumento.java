package com.ejemplo.banco.enums;

public enum TipoDocumento {

	   CEDULA, DNI, PASAPORTE

	}
