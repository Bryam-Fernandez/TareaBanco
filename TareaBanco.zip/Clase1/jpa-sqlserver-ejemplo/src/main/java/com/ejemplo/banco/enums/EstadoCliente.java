package com.ejemplo.banco.enums;

public enum EstadoCliente {

	   ACTIVO, INACTIVO, BLOQUEADO

	}
